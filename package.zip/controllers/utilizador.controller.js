const Utilizador = require("../models/utilizador.model.js");

//cria e regista um novo utiliazdor
exports.create = (req, res) => {
    //valida se os dados foram enviados da view 
    if(!req.body){
        res.status(400).send({
            message: "O conteúdo não pode estar vazio!"
        });
    }

    //cria um objeto do tipo utilizador com os dados
    const Utilizador = new Utilizador({
        nome: req.body.nome,
        dtaRegisto: req.body.dataregisto,
        //...
    });

    //salva o utilizador na bd
    Utilizador.create(Utilizador, (error, data) => {
        if (error)
        res.status(500).send({
            message:
            error.message || "Ocorreu um erro ao tentar criar um novo utilizador"
        });
        else res.send(data);
    });
};

//retorna todos os utilizadores da base de dados
exports.findAll = (req, res) => {
    Utilizador.getAll((error, data) => {
        if (error)
        res.status(500).send({
            message:
            error.message || "Ocorreu um erro ao tentar aceder aos dados dos utilizadores"
        });
        else res.send(data);
    });
};

//retorna um utilizador específico de acordo com o seu id
exports.findOne = (req,res) => {
    Utilizador.findById(req.params.id, (error, data) => {
        if (error) {
            if (error.result === "não encontrado") {
                res.status(404).send({
                    message: "Utilizador com o id ${req.params.id} não encontrado."
                });
            } else {
                res.status(500).send({
                    message: "Ocorreu um erro ao tentar aceder aos dados do utilizador com o ID " + req.params.id + '.'
                });
            } 
        }else res.send(data);
    });
};