const express = require("express");
const router = express.Router();
var path = require('path');
const Utilizador = require("../models/utilizador.model.js");
const Equipamento = require("../models/equipamento.model.js");
const Planos = require("../models/planos.model.js");
const Planos_treino = require("../models/planos_treino.model.js");
const Exercicios = require("../models/exercicios.model.js");

router.get("/planos", async function(req,res){
    let dados = null;
    dados = await Planos.getAll();
    res.render(path.resolve('views/pages/planos/index.ejs'), { dados:dados });   
 });
 router.get("/planos/visualizar/:id", async function(req,res){
    const data = req.params.id;
    const [plano_id, user_id] = data.split("_");
    dados = await Planos.findById(plano_id);
    res.render(path.resolve('views/pages/planos/visualizar.ejs'), {dados:dados,user_id}); 
});

router.get("/planos/apagar/:id", async function(req,res){
    const data = req.params.id;
    const [plano_id, id_equipamento, id_utilizador,id_exercicio] = data.split("_");
    Planos.remove(plano_id, id_equipamento, id_utilizador,id_exercicio);
    let dados = null;
    dados = await Planos.getAll();
    res.render(path.resolve('views/pages/planos/index.ejs'), { dados:dados });
});

router.get("/planos/form", async function(req,res){
    dados = await Utilizador.getAll();
    res.render(path.resolve('views/pages/planos/create.ejs'), {dados:dados}); 
});
router.get("/planos/add/:id", async function(req,res){
    const data = req.params.id;
    const [plano_id, user_id] = data.split("_");
    exercicios = await Exercicios.getAll();
    equipamentos = await Equipamento.getAllEstado();
    nome_cliente = await Planos.findNameById(plano_id);
    res.render(path.resolve('views/pages/planos/add.ejs'), {dados:dados, exercicios:exercicios, equipamentos:equipamentos,plano_id,user_id}); 
});
router.post('/planos/create/dentroplano/:id', async function(req,res){
    const criar = req.body;
    const cliente_data = req.params.id;
    const [id_plano, utilizador_id] = cliente_data.split("_");
    resultado = await Planos_treino.create(criar,id_plano,utilizador_id);
    dados = await Planos.findById(id_plano);
    user_id = utilizador_id;
    res.render(path.resolve('views/pages/planos/visualizar.ejs'), {dados:dados,user_id})
  });


  router.post('/planos/create/', async function(req,res){
    const criar = req.body;
    console.log(criar);
    const data = criar.cliente
    const [user_id,user_nome] = data.split("_");
    Planos.create(criar);
    let dados = null
    dados = await Planos.getSpecific(criar);
    const plano_id = (dados[0].plano_id);
    exercicios = await Exercicios.getAll();
    equipamentos = await Equipamento.getAllEstado();
    res.render(path.resolve('views/pages/planos/add.ejs'), {dados:dados,exercicios:exercicios, equipamentos:equipamentos,plano_id,user_id});
  });

  router.get("/planos/editar/:id/", async function(req,res) {
    const user_id = req.params.id;
    const data = req.params.id;
    const [cliente_id, id_equipamento,id_exercicio] = data.split("_");
    const dados = await Planos.findById(user_id);
    res.render(path.resolve('views/pages/planos/update.ejs'), {dados:dados,id_equipamento,id_exercicio,cliente_id}); 
})
router.get("/planos/edit/:id/", async function(req,res) {
    const user_id = req.params.id;
    const dados = await Planos.findById(user_id);
    datainicio = new Date(dados[0].p_datai).toISOString().replace(/T/, ' ').replace(/\..+/, ',');
    datafim = new Date(dados[0].p_dataf).toISOString().replace(/T/, ' ').replace(/\..+/, ',');
    function strBefore (string, delimiter) {  
        return delimiter === ''
          ? string
          : string.split(delimiter).shift()
      }
    const datasi = datainicio;
    const p_datai = strBefore(datasi, ' ');
    const datasf = datafim;
    const p_dataf = strBefore(datasf, ' ');


    res.render(path.resolve('views/pages/planos/update_plano.ejs'), {dados:dados,p_datai,p_dataf,user_id}); 
})


router.post('/planos/update/:id', async function(req,res){
    const mudar = req.body;
    const data = req.params.id;
    Planos.update(mudar,data);
    const [id_equipamento, id_exercicio,plano_id] = data.split("_");
    dados = await Planos.findById(plano_id);
    res.render(path.resolve('views/pages/planos/visualizar.ejs'), {dados:dados});
  });

  router.post('/planos/atualizar/:id', async function (req, res) {
      const mudar = req.body;
      const data = req.params.id;
      const [id_user,id_plano] = data.split("_");
      Planos.atualizar(mudar,id_user,id_plano);
      dados = await Planos.getAll();
      res.render(path.resolve('views/pages/planos/index.ejs'), {dados:dados});
  })



  module.exports = router;