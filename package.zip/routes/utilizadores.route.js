const express = require("express");
const router = express.Router();
var path = require('path');
const Utilizador = require("../models/utilizador.model.js");
const Equipamento = require("../models/equipamento.model.js");
const Planos = require("../models/planos.model.js");
const Planos_treino = require("../models/planos_treino.model.js");
const Exercicios = require("../models/exercicios.model.js");

router.get("/utilizadores", async function(req,res){
    let dados = null;
    dados = await Utilizador.getAll();
    res.render(path.resolve('views/pages/utilizadores/index.ejs'), { dados:dados });   
 });

 router.get("/form", function(req,res){
    res.render(path.resolve('views/pages/utilizadores/create.ejs')); 
});

router.get("/editar/:id/", async function(req,res) {
    const user_id = req.params.id;
    const dados = await Utilizador.findById(user_id);
    res.render(path.resolve('views/pages/utilizadores/update.ejs'), {dados:dados}); 
})

router.post('/update', async function(req,res){
    const mudar = req.body;
    Utilizador.update(mudar);
    let dados = null
    dados = await Utilizador.getAll();
    res.render(path.resolve('views/pages/utilizadores/index.ejs'), {dados:dados});
  });

  router.get("/apagar/:id", async function(req,res){
    const user_id = req.params.id;
    Utilizador.remove(user_id);
    let dados = null
    dados = await Utilizador.getAll();
    res.render(path.resolve('views/pages/utilizadores/index.ejs'), {dados:dados}); 
});


module.exports = router;