const { user } = require('../config/db.config.js');

    
    const bodyParser = require('body-parser');

    const Utilizador = require("../models/utilizador.model.js");
    const Equipamento = require("../models/equipamento.model.js");
    const Planos = require("../models/planos.model.js");
    const Planos_treino = require("../models/planos_treino.model.js");
    const Exercicios = require("../models/exercicios.model.js");
    const express = require('express');
    const router = express.Router();
    var path = require('path');



    
    router.get("/", async function(req,res){
        res.render(path.resolve('views/pages/index.ejs'), {msg : 0});  
    });

    module.exports = router;
