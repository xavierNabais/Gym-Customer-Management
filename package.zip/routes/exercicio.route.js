const express = require("express");
const router = express.Router();
var path = require('path');
const Utilizador = require("../models/utilizador.model.js");
const Equipamento = require("../models/equipamento.model.js");
const Planos = require("../models/planos.model.js");
const Planos_treino = require("../models/planos_treino.model.js");
const Exercicios = require("../models/exercicios.model.js");

router.post('/exercicios/update', async function(req,res){
    const mudar = req.body;
    Exercicios.update(mudar);
    let dados = null
    dados = await Exercicios.getAll();
    res.render(path.resolve('views/pages/exercicios/index.ejs'), {dados:dados});
  });

  router.get("/exercicios/editar/:id/", async function(req,res) {
    const user_id = req.params.id;
    const dados = await Exercicios.findById(user_id);
    equipamento = await Equipamento.getAll();
    res.render(path.resolve('views/pages/exercicios/update.ejs'), {dados:dados, equipamento:equipamento}); 
})

router.post('/exercicios/create', async function(req,res){
    const criar = req.body;
    Exercicios.create(criar);
    let dados = null
    dados = await Exercicios.getAll();
    res.render(path.resolve('views/pages/exercicios/index.ejs'), {dados:dados});
  });

  router.get("/exercicios/form", async function(req,res){
    dados = await Equipamento.getAll();
    res.render(path.resolve('views/pages/exercicios/create.ejs'), {dados:dados}); 
});

router.get("/exercicios/apagar/:id", async function(req,res){
    const user_id = req.params.id;
    Exercicios.remove(user_id);
    let dados = null
    dados = await Exercicios.getAll();
    res.render(path.resolve('views/pages/exercicios/index.ejs'), {dados:dados}); 
});

router.get("/exercicios", async function(req,res){
    let dados = null;
    dados = await Exercicios.getAll();
    res.render(path.resolve('views/pages/exercicios/index.ejs'), { dados:dados });   
 });


 module.exports = router;