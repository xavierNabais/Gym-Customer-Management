const express = require("express");
const router = express.Router();
var path = require('path');
const Utilizador = require("../models/utilizador.model.js");
const Equipamento = require("../models/equipamento.model.js");
const Planos = require("../models/planos.model.js");
const Planos_treino = require("../models/planos_treino.model.js");
const Exercicios = require("../models/exercicios.model.js");


router.get("/equipamento", async function(req,res){
    let dados = null;
    dados = await Equipamento.getAll();
    res.render(path.resolve('views/pages/equipamento/index.ejs'), { dados:dados });   
 });

 router.get("/equipamento/apagar/:id", async function(req,res){
    const user_id = req.params.id;
    Equipamento.remove(user_id);
    let dados = null
    dados = await Equipamento.getAll();
    res.render(path.resolve('views/pages/equipamento/index.ejs'), {dados:dados}); 
});

router.get("/equipamento/form", function(req,res){
    res.render(path.resolve('views/pages/equipamento/create.ejs')); 
});

router.post('/equipamento/create', async function(req,res){
    const criar = req.body;
    Equipamento.create(criar);
    let dados = null
    dados = await Equipamento.getAll();
    res.render(path.resolve('views/pages/equipamento/index.ejs'), {dados:dados});
  });

router.get("/equipamento/editar/:id/", async function(req,res) {
    const user_id = req.params.id;
    const dados = await Equipamento.findById(user_id);
    res.render(path.resolve('views/pages/equipamento/update.ejs'), {dados:dados}); 
})

router.post('/equipamento/update', async function(req,res){
    const mudar = req.body;
    Equipamento.update(mudar);
    let dados = null
    dados = await Equipamento.getAll();
    res.render(path.resolve('views/pages/equipamento/index.ejs'), {dados:dados});
  });


  module.exports = router;