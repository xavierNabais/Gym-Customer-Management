//importação da ligação à base de dados
const { promise } = require('./conexao.db');
const conexao = require('./conexao.db');

//definição da tabela na bd de forma abstrata
const Planos = function (dados) {
    this.nome = dados.nome,
    this.username = dados.username,
    this.password = dados.password,
    this.morada = dados.morada,
    this.contato = dados.contato,
    this.cargo = dados.cargo
}  


Planos.create = async (criar, res) => {
    const today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    var data = yyyy + '/' + mm + '/' + dd;
    
    const user = await conexao.promise().query('INSERT INTO planos(nome,data_inicio,data_fim,data_criacao,data_atualizacao) VALUES(?,?,?,?,?)', [criar.nome_plano, criar.data_inicio, criar.data_fim,data,data]);
};


//update registo
Planos.update = async (mudar,data, result) => {
    const [id_equipamento, id_exercicio,plano_id] = data.split("_");
    const user = await conexao.promise().query(
        `UPDATE planos_treino SET repeticoes='${mudar.repeticoes}',carga='${mudar.carga}',intervalo='${mudar.intervalo}' WHERE id_equipamento = '${id_equipamento}' AND plano_id='${plano_id}' AND id_exercicio='${id_exercicio}'`);
    };


Planos.atualizar = async (mudar,id_user,id_plano, result) =>{
    const today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }
    if (mm < 10) {
        mm = '0' + mm;
    }
    var data = yyyy + '/' + mm + '/' + dd;

    const user = await conexao.promise().query(
        `UPDATE planos SET nome='${mudar.pnome}',data_inicio='${mudar.datai}',data_fim='${mudar.dataf}', data_atualizacao='${data}' WHERE plano_id = '${id_plano}' `);

};



//pesquisa e retorna um registo de acordo com o seu ID
Planos.findById = async (plano_id, result) => {
    const dados = await conexao.promise().query(`SELECT planos.data_inicio as p_datai, planos.data_fim as p_dataf, planos_treino.plano_id as id_plano, planos_treino.carga, planos_treino.repeticoes, planos_treino.intervalo, planos.nome as p_nome, exercicios.nome as exerc_nome, exercicios.id_exercicio as id_exercicio, equipamento.nome as equip_nome, equipamento.id_equipamento as id_equipamento, utilizador.nome as user_nome, utilizador.utilizador_id as id_utilizador FROM planos_treino JOIN exercicios ON exercicios.id_exercicio = planos_treino.id_exercicio JOIN equipamento ON equipamento.id_equipamento = planos_treino.id_equipamento JOIN utilizador ON utilizador.utilizador_id = planos_treino.utilizador_id JOIN planos ON planos.plano_id = planos_treino.plano_id WHERE planos_treino.plano_id = '${plano_id}' AND equipamento.estado = 1`);
        return (dados[0]);
};
Planos.findById = async (plano_id, result) => {
    const dados = await conexao.promise().query(`SELECT planos.data_inicio as p_datai, planos.data_fim as p_dataf, planos_treino.plano_id as id_plano, planos_treino.carga, planos_treino.repeticoes, planos_treino.intervalo, planos.nome as p_nome, exercicios.nome as exerc_nome, exercicios.id_exercicio as id_exercicio, equipamento.nome as equip_nome, equipamento.id_equipamento as id_equipamento, utilizador.nome as user_nome, utilizador.utilizador_id as id_utilizador FROM planos_treino JOIN exercicios ON exercicios.id_exercicio = planos_treino.id_exercicio JOIN equipamento ON equipamento.id_equipamento = planos_treino.id_equipamento JOIN utilizador ON utilizador.utilizador_id = planos_treino.utilizador_id JOIN planos ON planos.plano_id = planos_treino.plano_id WHERE planos_treino.plano_id = '${plano_id}' AND equipamento.estado = 1`);
        return (dados[0]);
};
//pesquisa e retorna um registo de acordo com o seu ID
Planos.findNameById = async (plano_id, result) => {
    const dados_name = await conexao.promise().query(`SELECT planos_treino.plano_id as id_plano, planos_treino.carga, planos_treino.repeticoes, planos_treino.intervalo, planos.nome as p_nome, exercicios.nome as exerc_nome, exercicios.id_exercicio as id_exercicio, equipamento.nome as equip_nome, equipamento.id_equipamento as id_equipamento, utilizador.nome as user_nome, utilizador.utilizador_id as id_utilizador FROM planos_treino JOIN exercicios ON exercicios.id_exercicio = planos_treino.id_exercicio JOIN equipamento ON equipamento.id_equipamento = planos_treino.id_equipamento JOIN utilizador ON utilizador.utilizador_id = planos_treino.utilizador_id JOIN planos ON planos.plano_id = planos_treino.plano_id WHERE planos_treino.plano_id = '${plano_id}' AND equipamento.estado = 1 LIMIT 1`);
        return (dados_name[0]);
};

Planos.getSpecific = async (criar, result) =>{
    const dados = await conexao.promise().query(`SELECT plano_id FROM planos WHERE nome = '${criar.nome_plano}' AND data_inicio = '${criar.data_inicio}' AND data_fim = '${criar.data_fim}' LIMIT 1`);
    return (dados[0]);
};


Planos.getAll = async result => {
    const dados = await conexao.promise().query('SELECT planos.data_inicio as planos_datai,utilizador.utilizador_id as id_user, planos.data_fim as planos_dataf, planos.plano_id, planos.nome as plano_nome, utilizador.nome FROM planos JOIN planos_treino ON planos.plano_id = planos_treino.plano_id JOIN utilizador ON utilizador.utilizador_id = planos_treino.utilizador_id GROUP BY planos.plano_id');
    return(dados[0]);
};



//remove o registo de acordo com o id
Planos.remove = async(plano_id,id_equipamento,id_utilizador,id_exercicio, result) => {

    conexao.query(`DELETE FROM planos_treino WHERE plano_id='${plano_id}'`, (error, res) => {
        if (error) {
            console.log("error: ", error);
            return;
        }
        console.log("Planos apagado com o ID de equipamento, id de plano, id de utilizador: ", id_equipamento,plano_id,id_utilizador);
    });

};


module.exports = Planos;