//importação da ligação à base de dados
const { promise } = require('./conexao.db');
const conexao = require('./conexao.db');

//definição da tabela na bd de forma abstrata
const Equipamento = function (dados) {
    this.nome = dados.nome,
    this.estado = dados.estado,
    this.musculo = dados.password
}  

Equipamento.registo = async (campos, res) => {
    try {
        const user = await conexao.promise().query(`SELECT * FROM equipamento WHERE username='${campos.username}' LIMIT 1`);

        if (user[0].length > 0) {
            throw "Equipamento existente";
        } else {
            const today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1;
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = '0' + dd;
            }
            if (mm < 10) {
                mm = '0' + mm;
            }
            var data = yyyy + '/' + mm + '/' + dd;

            await conexao.promise().query(
                'INSERT INTO Equipamento(nome,username,password,cargo,morada,contato,data_criacao,data_atualizacao) VALUES(?,?,?,?,?,?,?,?)', [campos.nome, campos.username, campos.password, campos.cargo, campos.morada, campos.contato, data, data]);
        }

    } catch (err) {
        console.error(err);
        throw err;
    }
}

Equipamento.create = async (criar, res) => {
    const user = await conexao.promise().query('INSERT INTO equipamento(nome,estado,musculo) VALUES(?,?,?)', [criar.nome, criar.estado, criar.musculo]);
};


//update registo
Equipamento.update = async (mudar, result) => {
    const user = await conexao.promise().query(
        `UPDATE equipamento SET nome='${mudar.nome}',estado='${mudar.estado}',musculo='${mudar.musculo}' WHERE id_equipamento = '${mudar.numero}'`);
};

//pesquisa e retorna um registo de acordo com o seu ID
Equipamento.findById = async (user_id, result) => {
    try {
        const user =  await conexao.promise().query(`SELECT * FROM Equipamento WHERE id_equipamento = ${user_id}`);
        return user[0]
    }catch(err){
        console.error(err);
        throw err;
    }
};


Equipamento.getAll = async result => {
    const dados = await conexao.promise().query('SELECT * FROM equipamento');
    return dados[0];
};
Equipamento.getAllEstado = async result => {
    const dados = await conexao.promise().query('SELECT * FROM equipamento WHERE estado = 1');
    return dados[0];
};


//remove o registo de acordo com o id
Equipamento.remove= (id, result) => {
    conexao.query('DELETE FROM planos_treino WHERE id_equipamento = ?', id, (error,res) => {
        if (error){
            console.log("error: ", error);

            return;
        }
        console.log("Registo apagado em planos_treino com o id de equipamento: ", id);
    });
    conexao.query('DELETE FROM equipamento WHERE id_equipamento = ?', id, (error, res) => {
        if (error) {
            console.log("error: ", error);
            
            return;
        }
        console.log("Equipamento apagado com o ID: ", id);
    });
};


module.exports = Equipamento;